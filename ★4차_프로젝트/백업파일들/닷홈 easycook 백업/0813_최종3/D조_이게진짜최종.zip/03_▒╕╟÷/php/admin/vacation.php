<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>이지쿡 | 강사</title>
  <style>
    main{
      top:200px;
    }
  </style>
  <?php
    include('header.php'); 
  ?>
    <main>
      <?php
        include('../include/ready.php');
        include('footer.php');
      ?>
  </body>
</html>